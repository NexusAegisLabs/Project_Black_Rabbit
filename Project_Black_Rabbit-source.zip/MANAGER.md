# Mesh manager

Open `/manage` for saved node inventory, modeled coverage circles and shortest paths, proposed intermediate sites, position history, health observations, maintenance tasks and radio trace history. The existing `/` route retains corridor and terrain tools, with saved-route loading and saving.

## Storage and identity

The private Sites dispatcher supplies authenticated identity. Every database operation scopes records to that identity; browser-supplied identity headers are not an authentication mechanism. Writes require same-origin JSON. Cloudflare D1 migrations in `drizzle/` own the schema. The local Sites plugin provides its separate development-only sign-in identity. Never seed real private keys or radio credentials in source or notes.

Node records store planned installation position separately from timestamped observed locations. Imported readings never establish a live connection. Recently heard means a radio report within 15 minutes, not confirmed end-to-end delivery. Older reports are stale, not proven offline. Radio database readings retain last-heard time and can contain older cached metrics.

## Radio integration

Meshtastic uses the official JavaScript SDK over Web Serial or Web Bluetooth. Match saved inventory radio IDs to `!xxxxxxxx` IDs before saving readings. Optional monitoring saves matching records once a minute while the browser stays open and connected; duplicate node/timestamp records are upserted. The manual save action also stores the last completed traceroute.

MeshCore uses `@liamcottle/meshcore.js` browser transports only. Native serial bindings are unnecessary and their build script is disabled. The MeshCore panel reads cached contacts and sends an explicitly supplied one-byte hash path trace, correlating the returned tag. A hash sequence is not a list of unique full node identities. MeshCore traces may include return paths. Full radio configuration and messaging remain in the official firmware companion apps.

Neither adapter has been tested against physical hardware in this session. No remote radio, MQTT bridge, continuous server radio process or background notification service is connected. Browser suspension or closing the page stops monitoring. Scheduled tasks are persistent maintenance reminders displayed in the app; they do not transmit radio traffic automatically.

## Models

Coverage circles use per-node user assumptions. The graph requires matching protocol and separation no greater than the smaller endpoint range. It excludes retired nodes and finds the fewest graph links. It does not verify firmware role, channel, region, preset, antenna pattern, interference or terrain. Suggested relays divide a direct geographic gap and require a survey. Terrain checks remain available in the corridor planner. No arbitrary protocol bridging or guaranteed Salem-to-Fall-River reachability is claimed.

## Validation

Nine Node tests cover planning geometry, fresh versus stale evidence, record validation and real SDK request/response handling with synthetic transports. `tests/database-check.py` validates the actual migration, owner-scoped upserts and indexed queries. `tests/api-check.mjs` tests the local HTTP endpoint: unauthenticated rejection, forged-header rejection, cross-origin write rejection, bad coordinates, save/read/delete. TypeScript and production build are checked before publication. No physical RF or browser visual testing is claimed.

## Source and GitHub

The Sites repository and the downloadable source archive contain the app source, not saved user records. A separate GitHub destination is pending; the connected account exposed no repositories during this update. Do not claim a GitHub push until a destination is available and the push succeeds.
