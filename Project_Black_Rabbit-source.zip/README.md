# Mesh Corridor — Salem to Fall River

A black-theme corridor planner and saved mesh manager with node inventory, placement, modeled coverage, health and position history, maintenance scheduling, and USB/Bluetooth radio trace clients. Open `/manage` for the manager; see [MANAGER.md](MANAGER.md) for capabilities and limits.

## Run

Use Node 22.13 or later and pnpm. Run `pnpm install`, then `pnpm dev`. Run `pnpm build` for production. Run `pnpm exec tsc --noEmit` and `node --experimental-strip-types --test tests/*.test.mjs` for checks.

## Behavior

- The initial six-node chain has four intermediate relay hops and five radio links. Distances are summed geodesic spans, not driving distances. Proposed tracing animates the chosen order; it does not predict reception or discover a proven network path.
- Unsaved corridor edits and public reports are session-local. Explicitly saved routes, node inventory, readings, traces and tasks persist in owner-scoped Cloudflare D1. Optional Meshtastic monitoring saves matched-node readings once a minute while connected.
- The included MeshMap snapshot records its actual acquisition time. The server can refresh public reports from the fixed MeshMap endpoint. Imports accept MeshMap JSON and filter to eastern MA / RI (latitude 41–43.1, longitude -72–-69.7). Public reports are not evidence of current connectivity.
- Terrain is sampled at 65 points from zoom-12 Terrarium elevation tiles. The model uses 915 MHz, 60% Fresnel clearance and a 4/3 Earth radius. It omits trees, buildings, interference, antenna gain and link budget. Geographic coordinate interpolation is intended for regional links; terrain requests are limited to 250 km.
- Real traces use the official Meshtastic SDK over browser USB serial or Bluetooth. This transmits only when the user selects Send live trace. It uses the radio's existing primary-channel settings and never changes configuration. Matching responses are correlated using destination, recipient and request ID. No response times out after 60 seconds.
- MeshCore USB/Bluetooth companion connections support explicit one-byte hash path traces and saved results. Full configuration and messaging use official companion apps. Wi-Fi/remote radio transport is not connected. Meshtastic and MeshCore are separate networks.
- Map tiles and terrain require an internet connection; radios can communicate without internet. The hosted page itself must first be loaded online.

## Dependencies and attribution

Meshtastic core 2.6.7 and Web Serial/Bluetooth transports are GPL-3.0-only, unmodified npm packages from https://github.com/meshtastic/js. The app is supplied under GPL-3.0-only to support its combined client distribution. See LICENSE. Source and package-lock configuration are included; third-party packages retain their own notices and licenses. The small browser-logging adapter only supplies the Node logger imports accidentally bundled by the SDK; it does not alter radio protocol handling.

Leaflet: BSD-2-Clause. Map tiles: CARTO and OpenStreetMap contributors. Public node reports: MeshMap.net. Terrain: Mapzen Terrarium with USGS 3DEP/NED, GMTED2010 and SRTM attribution. Meshtastic and MeshCore marks belong to their respective owners. This planner is independent.

## Validation limits

No physical radio was supplied for this build. Over-the-air radio behavior must be tested with supported hardware. A successful build or simulated protocol test is not a field test. Browser transport availability varies; desktop Chrome/Edge is recommended for USB.
