import { normalizePublicNodes } from '@/lib/planner';
export async function GET(){
  try{const r=await fetch('https://meshmap.net/nodes.json',{signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('MeshMap unavailable');const text=await r.text();if(text.length>20000000)throw new Error('Dataset too large');const nodes=normalizePublicNodes(JSON.parse(text));return Response.json({capturedAt:new Date().toISOString(),nodes},{headers:{'Cache-Control':'public, max-age=300'}});}
  catch{return Response.json({error:'Public reports could not be refreshed. Keep the existing snapshot or import a MeshMap JSON file.'},{status:502});}
}
