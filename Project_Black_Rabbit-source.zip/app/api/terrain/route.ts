export async function GET(request:Request){
  const p=new URL(request.url).searchParams,x=Number(p.get('x')),y=Number(p.get('y'));
  if(!p.has('x')||!p.has('y')||!Number.isInteger(x)||!Number.isInteger(y)||x<0||x>=4096||y<0||y>=4096)return new Response('Invalid tile',{status:400});
  try{const r=await fetch(`https://s3.amazonaws.com/elevation-tiles-prod/terrarium/12/${x}/${y}.png`,{signal:AbortSignal.timeout(12000)});if(!r.ok)throw new Error('Unavailable');return new Response(await r.arrayBuffer(),{headers:{'Content-Type':'image/png','Cache-Control':'public, max-age=86400'}});}
  catch{return new Response('Terrain data is unavailable. Try again later.',{status:502});}
}
