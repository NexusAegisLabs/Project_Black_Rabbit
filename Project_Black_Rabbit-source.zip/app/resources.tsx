const groups=[
 {name:'Meshtastic',note:'Official project resources and community maps.',links:[
 ['Official website','https://meshtastic.org/'],
 ['Live community node map','https://meshtastic.liamcottle.net/'],
 ['MeshMap public reports','https://meshmap.net/'],
 ['Getting started & supported radios','https://meshtastic.org/docs/getting-started/'],
 ['Radio settings & hop limits','https://meshtastic.org/docs/configuration/radio/lora/'],
 ['Web client','https://client.meshtastic.org/'],
 ['Firmware flasher','https://flasher.meshtastic.org/'],
 ['MeshtasticD software nodes','https://meshtastic.org/docs/meshtasticd/installation/'],
 ['MQTT internet gateways','https://meshtastic.org/docs/configuration/module/mqtt/'],
 ]},
 {name:'MeshCore',note:'Official map, firmware and connection guides.',links:[
 ['Official website','https://meshcore.io/'],
 ['Official live node map · eastern MA / RI','https://map.meshcore.io/?lat=42.1&lon=-71.05&zoom=9'],
 ['Documentation & setup guides','https://docs.meshcore.io/'],
 ['Firmware flasher','https://flasher.meshcore.io/'],
 ['Companion web app','https://app.meshcore.nz/'],
 ['Firmware source & releases','https://github.com/meshcore-dev/MeshCore'],
 ]},
];
export default function Resources(){return <section id="maps-resources" className="panel resources"><p className="eyebrow">MAPS & RESOURCES</p><h2>Explore the networks</h2><p className="small muted">Open the source maps for their latest reports. A reported node is not proof that it is online or reachable from your radio.</p><div className="resource-grid">{groups.map(g=><section key={g.name}><h3>{g.name}</h3><p className="small muted">{g.note}</p><ul>{g.links.map(([label,url])=><li key={url}><a href={url} target="_blank" rel="noreferrer">{label} <span aria-hidden="true">↗</span></a></li>)}</ul></section>)}</div><p className="small muted">Independent planner · <a href="/source.zip" download>Download source (GPL-3.0)</a></p></section>;}

