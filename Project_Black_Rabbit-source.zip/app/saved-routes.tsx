'use client';
import {useState} from 'react';
import {Button} from '@/components/ui/button';
import type {NodePoint} from '@/lib/planner';
export default function SavedRoutes({nodes,onLoad}:{nodes:NodePoint[];onLoad:(nodes:NodePoint[])=>void}){
 const[routes,setRoutes]=useState<any[]>([]),[status,setStatus]=useState(''),[name,setName]=useState('My corridor'),[busy,setBusy]=useState(false);
 async function load(){setBusy(true);try{const r=await fetch('/api/manager'),d:any=await r.json();if(!r.ok)throw new Error(d.error);setRoutes(d.route);setStatus(d.route.length?'Choose a saved route.':'No saved routes yet.');}catch(e){setStatus((e as Error).message);}finally{setBusy(false);}}
 async function save(){setBusy(true);try{const r=await fetch('/api/manager',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:'route',record:{id:crypto.randomUUID(),name,nodes}})}),d:any=await r.json();if(!r.ok)throw new Error(d.error);setStatus('Route saved to your network.');}catch(e){setStatus((e as Error).message);}finally{setBusy(false);}}
 return <section className="panel"><div className="section-heading"><h2>Saved network plans</h2><a href="/manage">Open network manager ↗</a></div><div className="actions"><input aria-label="Route name" maxLength={100} value={name} onChange={e=>setName(e.target.value)}/><Button disabled={busy||!name} onClick={()=>void save()}>Save current route</Button><Button variant="outline" disabled={busy} onClick={()=>void load()}>Load saved routes</Button></div><p role="status">{status}</p>{routes.map(r=><Button key={r.id} variant="outline" onClick={()=>{onLoad(r.nodes);setName(r.name);setStatus('Saved route loaded into the map.');}}>{r.name}</Button>)}</section>;
}
