import {sqliteTable,text,integer,primaryKey} from 'drizzle-orm/sqlite-core';
export const records=sqliteTable('mesh_records',{
 owner:text('owner').notNull(), id:text('id').notNull(), kind:text('kind').notNull(),
 body:text('body').notNull(), updated:integer('updated').notNull(),
},table=>[primaryKey({columns:[table.owner,table.kind,table.id]})]);
