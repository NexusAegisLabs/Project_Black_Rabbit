CREATE TABLE `mesh_records` (
	`owner` text NOT NULL,
	`id` text NOT NULL,
	`kind` text NOT NULL,
	`body` text NOT NULL,
	`updated` integer NOT NULL,
	PRIMARY KEY(`owner`, `kind`, `id`)
);
