export type MeshNode={id:string;name:string;protocol:'Meshtastic'|'MeshCore';hardware:string;role:string;stage:'planned'|'installed'|'retired';lat:number;lon:number;height:number;rangeKm:number;radioId:string;notes:string};
export type Reading={id:string;nodeId:string;time:number;source:'radio'|'manual'|'import';battery:number|null;snr:number|null;rssi:number|null;voltage:number|null;lat:number|null;lon:number|null;note:string};
export type Job={id:string;nodeId:string;title:string;due:string;repeatDays:number;done:boolean;notes:string};
export type SavedRoute={id:string;name:string;nodes:{id:string;name:string;lat:number;lon:number;note:string}[]};
export type Trace={id:string;protocol:string;time:number;path:string[];note:string};
export type MeshData={node:MeshNode[];reading:Reading[];job:Job[];route:SavedRoute[];trace:Trace[]};
export const emptyData:MeshData={node:[],reading:[],job:[],route:[],trace:[]};
const text=(v:unknown,max:number)=>typeof v==='string'&&v.length<=max;
const num=(v:unknown,min:number,max:number)=>typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max;
const optional=(v:unknown,min:number,max:number)=>v===null||num(v,min,max);
export function validRecord(kind:string,v:any):boolean{
 if(!v||!text(v.id,100)||!v.id)return false;
 if(kind==='node')return text(v.name,100)&&!!v.name&&['Meshtastic','MeshCore'].includes(v.protocol)&&text(v.hardware,100)&&text(v.role,100)&&['planned','installed','retired'].includes(v.stage)&&num(v.lat,-85,85)&&num(v.lon,-180,180)&&num(v.height,0,1000)&&num(v.rangeKm,.1,100)&&text(v.radioId,100)&&text(v.notes,3000);
 if(kind==='reading')return text(v.nodeId,100)&&num(v.time,1,Date.now()+60000)&&['radio','manual','import'].includes(v.source)&&optional(v.battery,0,101)&&optional(v.snr,-100,100)&&optional(v.rssi,-250,30)&&optional(v.voltage,0,100)&&optional(v.lat,-85,85)&&optional(v.lon,-180,180)&&text(v.note,1000);
 if(kind==='job')return text(v.nodeId,100)&&text(v.title,200)&&!!v.title&&text(v.due,30)&&Number.isFinite(Date.parse(v.due))&&num(v.repeatDays,0,3650)&&Number.isInteger(v.repeatDays)&&typeof v.done==='boolean'&&text(v.notes,3000);
 if(kind==='route')return text(v.name,100)&&Array.isArray(v.nodes)&&v.nodes.length>=2&&v.nodes.length<=50&&v.nodes.every((n:any)=>text(n.id,100)&&text(n.name,100)&&text(n.note,3000)&&num(n.lat,-85,85)&&num(n.lon,-180,180));
 if(kind==='trace')return ['Meshtastic','MeshCore'].includes(v.protocol)&&num(v.time,1,Date.now()+60000)&&Array.isArray(v.path)&&v.path.length>=2&&v.path.length<=100&&v.path.every((p:any)=>text(p,100))&&text(v.note,3000);
 return false;
}
export function nodeHealth(node:MeshNode,readings:Reading[],now=Date.now()){
 if(node.stage!=='installed')return node.stage;
 const latest=readings.filter(r=>r.nodeId===node.id&&r.source==='radio').sort((a,b)=>b.time-a.time)[0];
 return !latest?'unverified':now-latest.time<=15*60000?'recently heard':'stale';
}
export function km(a:{lat:number;lon:number},b:{lat:number;lon:number}){const rad=Math.PI/180;const h=Math.sin((b.lat-a.lat)*rad/2)**2+Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin((b.lon-a.lon)*rad/2)**2;return 12742*Math.asin(Math.sqrt(Math.min(1,h)));}
export function plannedPath(nodes:MeshNode[],start:string,end:string){
 const pool=nodes.filter(n=>n.stage!=='retired'),origin=pool.find(n=>n.id===start),target=pool.find(n=>n.id===end);if(!origin||!target||origin.protocol!==target.protocol)return null;
 const queue=[[origin]],seen=new Set([start]);while(queue.length){const path=queue.shift()!,last=path.at(-1)!;if(last.id===end)return path;for(const n of pool){if(!seen.has(n.id)&&n.protocol===origin.protocol&&km(last,n)<=Math.min(last.rangeKm,n.rangeKm)){seen.add(n.id);queue.push([...path,n]);}}}return null;
}
export function relaySuggestions(a:MeshNode,b:MeshNode){const span=km(a,b),limit=Math.min(a.rangeKm,b.rangeKm),segments=Math.ceil(span/limit);if(segments<=1)return[];return Array.from({length:Math.min(segments-1,50)},(_,i)=>{const t=(i+1)/segments;return{lat:a.lat+(b.lat-a.lat)*t,lon:a.lon+(b.lon-a.lon)*t};});}
