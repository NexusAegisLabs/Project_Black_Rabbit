declare module '@liamcottle/meshcore.js/src/connection/web_serial_connection.js' {const Connection:any;export default Connection;}
declare module '@liamcottle/meshcore.js/src/connection/web_ble_connection.js' {const Connection:any;export default Connection;}
