export type NodePoint = { id: string; name: string; lat: number; lon: number; note: string };
export type PublicNode = { id: string; name: string; lat: number; lon: number; lastSeen: number; hardware: string; role: string; preset: string };
export const candidates: NodePoint[] = [
  {id:'salem',name:'Castle Hill, Salem',lat:42.506,lon:-70.903,note:'Move this pin to your actual roof. Seek a clear southwest exposure.'},
  {id:'lynn',name:'High Rock area, Lynn',lat:42.4674,lon:-70.9495,note:'Scout a permitted elevated site near High Rock with views toward Salem and Boston.'},
  {id:'blue-hill',name:'Great Blue Hill area',lat:42.2127,lon:-71.1141,note:'Highest ground on this candidate route. Summit access and installation permission are not established.'},
  {id:'brockton',name:'Brockton / West Bridgewater',lat:42.06,lon:-71.025,note:'Search for an elevated host with north and south clearance. This pin does not identify a tower.'},
  {id:'taunton',name:'Taunton area',lat:41.901,lon:-71.09,note:'A southern stepping stone. Flat wooded terrain makes mounting height especially important.'},
  {id:'fall-river',name:'Fall River',lat:41.7015,lon:-71.155,note:'Move to the actual destination. An elevated north-facing roof is the first scouting target.'},
];
export function validCoordinates(lat: number, lon: number) { return Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat)<=85 && Math.abs(lon)<=180; }
export function distance(a: Pick<NodePoint,'lat'|'lon'>, b: Pick<NodePoint,'lat'|'lon'>) {
  const rad=Math.PI/180, dlat=(b.lat-a.lat)*rad, dlon=(b.lon-a.lon)*rad;
  const h=Math.sin(dlat/2)**2+Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin(dlon/2)**2;
  return 6371000*2*Math.atan2(Math.sqrt(Math.min(1,h)),Math.sqrt(Math.max(0,1-h)));
}
export function fresnel(distanceM:number,t=0.5) {return Math.sqrt((299792458/915000000)*distanceM*t*(1-t))*0.6;}
export function profileModel(ground:number[],distanceM:number,ha:number,hb:number) {
  if(ground.length<3||ground.some(x=>!Number.isFinite(x))||distanceM<=0||ha<0||hb<0) throw new Error('Invalid profile inputs');
  const start=ground[0]+ha,end=ground[ground.length-1]+hb;
  return ground.map((elevation,i)=>{const t=i/(ground.length-1), earth=distanceM**2*t*(1-t)/(2*(4/3)*6371000), beam=start+(end-start)*t; return {t,ground:elevation+earth,beam,lower:beam-fresnel(distanceM,t),clearance:beam-fresnel(distanceM,t)-elevation-earth};});
}
export function normalizePublicNodes(input: unknown): PublicNode[] {
  if(!input||typeof input!=='object')throw new Error('Expected a MeshMap JSON object or array.');
  const root=(input as any).nodes ?? input;
  if(!root||typeof root!=='object')throw new Error('No nodes found in this file.');
  const result:PublicNode[]=[];
  for(const [id,value] of Object.entries(root)){
    const n=value as any;if(!n||typeof n!=='object')continue;
    const p=n.position??n;
    let lat=Number(p.latitude??p.latitudeI??p.lat),lon=Number(p.longitude??p.longitudeI??p.lon);
    if(Math.abs(lat)>90)lat/=1e7;if(Math.abs(lon)>180)lon/=1e7;
    if(!validCoordinates(lat,lon)||lat<41||lat>43.1||lon<-72||lon>-69.7)continue;
    const seen=[n.lastSeen,n.lastHeard,n.lastMapReport,...Object.values(n.seenBy??{})].map(Number).filter(Number.isFinite);
    const lastSeen=seen.length?Math.max(...seen):0;
    result.push({id:String(n.id??id),name:String(n.longName??n.user?.longName??n.shortName??id).slice(0,120),lat,lon,lastSeen:lastSeen>1e12?lastSeen/1000:lastSeen,hardware:String(n.hwModel??n.user?.hwModel??'Unknown'),role:String(n.role??'Unknown'),preset:String(n.modemPreset??'Not reported')});
  }return result;
}
