// @meshtastic/core 2.6.7 bundles tslog's Node logger. Supply only the
// logger's three platform imports when that package is bundled for the web.
export const hostname=()=>typeof location==='undefined'?'browser':location.hostname;
export const normalize=(path:string)=>path.replaceAll('\\','/');
export const types={isNativeError:(value:unknown)=>value instanceof Error};
export function formatWithOptions(_options:unknown,...args:unknown[]){return args.map(value=>{if(typeof value==='string')return value;if(value instanceof Error)return value.message;try{return JSON.stringify(value);}catch{return String(value);}}).join(' ');}
