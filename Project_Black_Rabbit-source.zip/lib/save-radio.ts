export async function saveRadioSnapshot(db:Record<number,any>,report:any){
 const response=await fetch('/api/manager'),data:any=await response.json();if(!response.ok)throw new Error(data.error);
 async function save(kind:string,record:any){const r=await fetch('/api/manager',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind,record})});if(!r.ok)throw new Error(((await r.json()) as any).error);}
 let count=0;
 for(const [id,info] of Object.entries(db)){
 const radioId='!'+Number(id).toString(16).padStart(8,'0'),existing=data.node.find((n:any)=>n.protocol==='Meshtastic'&&n.radioId===radioId),p=info.position,lat=p?.latitudeI/1e7,lon=p?.longitudeI/1e7;
 if(!existing)continue;
 const time=info.lastHeard*1000;if(!time||time>Date.now()+60000)continue;const metrics=info.deviceMetrics??{};
 await save('reading',{id:`meshtastic-${id}-${time}`,nodeId:existing.id,time,source:'radio',battery:metrics.batteryLevel??null,voltage:metrics.voltage??null,snr:info.snr??null,rssi:info.rssi??null,lat:Number.isFinite(lat)&&Math.abs(lat)<=85?lat:null,lon:Number.isFinite(lon)&&Math.abs(lon)<=180?lon:null,note:'Received via connected Meshtastic radio. Cached node reports retain their original last-heard time; metrics may be older.'});count++;
 }
 if(report)await save('trace',{id:crypto.randomUUID(),protocol:'Meshtastic',time:Date.parse(report.time),path:report.route.map((n:number)=>n?'!'+n.toString(16).padStart(8,'0'):'Unknown relay'),note:'Real traceroute response. Relay identities and positions may be incomplete.'});
 return `${count} matched node readings saved${report?' with traceroute':''}. Match inventory radio IDs to save their readings.`;
}
