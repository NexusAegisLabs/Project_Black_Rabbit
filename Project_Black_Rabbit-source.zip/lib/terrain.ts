import { distance, type NodePoint } from './planner';
const cache=new Map<string,Promise<ImageData>>();
async function tile(x:number,y:number){
  const key=`${x}/${y}`;if(cache.has(key))return cache.get(key)!;
  const pending=(async()=>{const response=await fetch(`/api/terrain?x=${x}&y=${y}`,{signal:AbortSignal.timeout(16000)});if(!response.ok)throw new Error('Terrain service unavailable. Please retry.');const bitmap=await createImageBitmap(await response.blob());const canvas=document.createElement('canvas');canvas.width=256;canvas.height=256;const ctx=canvas.getContext('2d');if(!ctx)throw new Error('This browser cannot read elevation tiles.');ctx.drawImage(bitmap,0,0);bitmap.close();return ctx.getImageData(0,0,256,256);})();
  cache.set(key,pending);try{return await pending;}catch(e){cache.delete(key);throw e;}
}
export async function sampleTerrain(a:NodePoint,b:NodePoint){
  if(distance(a,b)<1)throw new Error('Move the nodes at least one meter apart.');
  if(distance(a,b)>250000)throw new Error('Select a link under 250 km for a useful terrain check.');
  const samples=Array.from({length:65},(_,i)=>{const t=i/64,lat=a.lat+(b.lat-a.lat)*t,lon=a.lon+(b.lon-a.lon)*t,s=Math.sin(lat*Math.PI/180);const tx=(lon+180)/360*4096,ty=(0.5-Math.log((1+s)/(1-s))/(4*Math.PI))*4096;return{x:Math.min(4095,Math.floor(tx)),y:Math.min(4095,Math.floor(ty)),px:Math.min(255,Math.floor((tx-Math.floor(tx))*256)),py:Math.min(255,Math.floor((ty-Math.floor(ty))*256))};});
  const results:number[]=[];
  for(let i=0;i<samples.length;i+=8){results.push(...await Promise.all(samples.slice(i,i+8).map(async p=>{const data=await tile(p.x,p.y),k=(p.py*256+p.px)*4;return data.data[k]*256+data.data[k+1]+data.data[k+2]/256-32768;})));}return results;
}
