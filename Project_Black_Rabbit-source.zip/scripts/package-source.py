from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
files = []
for folder in ('app', 'lib', 'components', 'hooks', 'tests', 'scripts', 'db', 'drizzle'):
    base = root / folder
    if base.exists():
        files.extend(p for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for name in ('package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'vite.config.ts', 'drizzle.config.ts', 'public/favicon.svg', 'next.config.ts', 'tsconfig.json', 'components.json', 'README.md', 'MANAGER.md', 'LICENSE', '.gitignore', '.openai/hosting.json', 'public/public-nodes.json'):
    p = root / name
    if p.exists():
        files.append(p)
with ZipFile(root / 'public' / 'source.zip', 'w', ZIP_DEFLATED) as archive:
    for p in sorted(set(files)):
        archive.write(p, p.relative_to(root))
print(f'Packaged {len(set(files))} source files; no credentials or local environment files.')
