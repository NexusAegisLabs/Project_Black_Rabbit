import assert from 'node:assert/strict';
const base='http://localhost:3000';
// Sites' documented local-only identity cookie; production does not use this cookie.
const headers={'Content-Type':'application/json','Origin':base,'Cookie':'__sites_local_auth=1'};
const record={id:'validation-node',name:'Validation only',protocol:'Meshtastic',hardware:'test',role:'client',stage:'planned',lat:42,lon:-71,height:2,rangeKm:2,radioId:'',notes:''};
assert.equal((await fetch(base+'/api/manager')).status,401);
async function post(body,h=headers){return fetch(base+'/api/manager',{method:'POST',headers:h,body:JSON.stringify(body)});}
assert.equal((await post({kind:'node',record},{...headers,Origin:'https://untrusted.invalid'})).status,403);
assert.equal((await post({kind:'node',record:{...record,lat:999}})).status,400);
const saved=await post({kind:'node',record});assert.equal(saved.status,200,await saved.text());
const own=await (await fetch(base+'/api/manager',{headers})).json();assert.ok(own.node.some(n=>n.id===record.id));
assert.equal((await fetch(base+'/api/manager',{headers:{'oai-authenticated-user-id':'forged-user'}})).status,401);
assert.equal((await post({kind:'node',record,remove:true})).status,200);
console.log('API authorization, cross-origin rejection, validation, persistence and forged-header rejection passed.');
