import sqlite3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
db=sqlite3.connect(':memory:')
for migration in sorted((root/'drizzle').glob('*.sql')): db.executescript(migration.read_text())
query='INSERT INTO mesh_records (owner,kind,id,body,updated) VALUES (?,?,?,?,?) ON CONFLICT(owner,kind,id) DO UPDATE SET body=excluded.body,updated=excluded.updated'
db.execute(query,('alice','node','one','{"name":"A"}',1))
db.execute(query,('bob','node','one','{"name":"B"}',1))
db.execute(query,('alice','node','one','{"name":"updated"}',2))
assert db.execute('SELECT body FROM mesh_records WHERE owner=?',('bob',)).fetchone()[0]=='{"name":"B"}'
assert db.execute('SELECT count(*) FROM mesh_records').fetchone()[0]==2
plan=db.execute('EXPLAIN QUERY PLAN SELECT kind,body FROM mesh_records WHERE owner=? ORDER BY updated DESC LIMIT 5000',('alice',)).fetchall()
assert any('INDEX' in row[-1] for row in plan)
print('Migration, owner isolation, upsert and indexed lookup verified.')
