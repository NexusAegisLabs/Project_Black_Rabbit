import test from 'node:test';
import assert from 'node:assert/strict';
import Connection from '@liamcottle/meshcore.js/src/connection/connection.js';
import Constants from '@liamcottle/meshcore.js/src/constants.js';
test('MeshCore trace serializes chosen hashes and resolves only a matching tag',async()=>{
 const c=new Connection();let sent;
 c.sendToRadioFrame=async bytes=>{sent=bytes;};
 const promise=c.tracePath(Uint8Array.from([0xaa,0xbb,0xaa]));
 await new Promise(resolve=>setTimeout(resolve,0));
 assert.equal(sent[0],Constants.CommandCodes.SendTracePath);
 assert.deepEqual(Array.from(sent.slice(10)),[0xaa,0xbb,0xaa]);
 const tag=new DataView(sent.buffer,sent.byteOffset,sent.byteLength).getUint32(1,true);
 let resolved=false;promise.then(()=>{resolved=true;});
 c.emit(Constants.PushCodes.TraceData,{tag:(tag+1)>>>0,pathHashes:new Uint8Array([0xcc])});
 await new Promise(resolve=>setTimeout(resolve,0));assert.equal(resolved,false);
 const expected={tag,pathHashes:Uint8Array.from([0xaa,0xbb,0xaa]),lastSnr:4};
 c.emit(Constants.PushCodes.TraceData,expected);assert.deepEqual(await promise,expected);
});
