import assert from 'node:assert/strict';
import test from 'node:test';
import {candidates,distance,fresnel,normalizePublicNodes,profileModel,validCoordinates} from '../lib/planner.ts';
test('Salem corridor distances and node/hop distinction',()=>{
 const total=candidates.slice(1).reduce((s,n,i)=>s+distance(candidates[i],n),0);
 assert.equal(candidates.length,6);assert.equal(candidates.length-2,4);assert.equal(candidates.length-1,5);
 assert.ok(Math.abs(total/1609.344-60.2)<.1);
 assert.ok(Math.abs(distance(candidates[0],candidates[1])-5740)<100);
 assert.equal(distance(candidates[0],candidates[0]),0);
 assert.ok(Math.abs(distance(candidates[0],candidates[1])-distance(candidates[1],candidates[0]))<1e-8);
});
test('Fresnel and curvature model detects blocked terrain',()=>{
 assert.ok(Math.abs(fresnel(5700)-13)<.1);
 const flat=profileModel(Array(65).fill(0),5700,30,30);
 assert.ok(Math.min(...flat.map(p=>p.clearance))>0);
 const ridge=Array(65).fill(0);ridge[32]=100;
 assert.ok(profileModel(ridge,5700,30,30)[32].clearance<0);
 assert.throws(()=>profileModel([0,NaN,0],100,15,15));
});
test('Public report imports normalize integer GPS and report time, rejecting outside-region coordinates',()=>{
 const sample={a:{longName:'Local',latitude:425060000,longitude:-709030000,seenBy:{one:100,two:200}},b:{latitude:10,longitude:10},c:{latitude:null,longitude:null}};
 const nodes=normalizePublicNodes(sample);assert.equal(nodes.length,1);assert.equal(nodes[0].lat,42.506);assert.equal(nodes[0].lastSeen,200);
 assert.equal(normalizePublicNodes({nodes:[{lat:42.2,lon:-71.1,lastSeen:1800000000000}]} )[0].lastSeen,1800000000);
 assert.throws(()=>normalizePublicNodes(null));assert.equal(validCoordinates(NaN,0),false);assert.equal(validCoordinates(42,-181),false);
});
