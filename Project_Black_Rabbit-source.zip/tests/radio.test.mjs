import test from 'node:test';
import assert from 'node:assert/strict';
import {MeshDevice,Protobuf} from '@meshtastic/core';

function fields(bytes){let i=0;const result=new Map();const varint=()=>{let n=0,shift=0,b;do{b=bytes[i++];n+=(b&127)*2**shift;shift+=7;}while(b&128);return n;};while(i<bytes.length){const key=varint(),no=key>>>3,wire=key&7;let value;if(wire===0)value=varint();else if(wire===5){value=new DataView(bytes.buffer,bytes.byteOffset+i,4).getUint32(0,true);i+=4;}else if(wire===2){const len=varint();value=bytes.slice(i,i+len);i+=len;}else throw new Error('Unexpected wire type');result.set(no,value);}return result;}
const field=(schema,name)=>schema.fields.find(f=>f.name===name).number;

test('Official SDK sends a unicast traceroute request and decodes returned relay IDs',async()=>{
 let controller,device,captured;
 const transport={fromDevice:new ReadableStream({start(c){controller=c;}}),toDevice:new WritableStream({write(bytes){captured=bytes;const id=device.queue.getState().at(-1).id;setTimeout(()=>device.queue.processAck(id),10);}}),async disconnect(){controller.close();}};
 device=new MeshDevice(transport);device.queue.timeout=500;
 const origin=0x12345678,destination=0xabcdef12;
 device.events.onMyNodeInfo.dispatch({myNodeNum:origin});
 const request=device.traceRoute(destination);
 const queuedId=device.queue.getState()[0].id;
 assert.equal(await request,queuedId);
 const outer=fields(captured),packet=fields(outer.get(field(Protobuf.Mesh.ToRadioSchema,'packet')));
 assert.equal(packet.get(field(Protobuf.Mesh.MeshPacketSchema,'to')),destination);
 assert.equal(packet.get(field(Protobuf.Mesh.MeshPacketSchema,'from')),origin);
 const data=fields(packet.get(field(Protobuf.Mesh.MeshPacketSchema,'decoded')));
 assert.equal(data.get(field(Protobuf.Mesh.DataSchema,'portnum')),70);
 assert.equal(data.get(field(Protobuf.Mesh.DataSchema,'want_response')),1);
 let rawRequest,received;
 device.events.onMeshPacket.subscribe(p=>{rawRequest=p.payloadVariant.value.requestId;});
 device.events.onTraceRoutePacket.subscribe(p=>{received=p;});
 const relay=0x10203040,payload=new Uint8Array(6);payload[0]=10;payload[1]=4;new DataView(payload.buffer).setUint32(2,relay,true);
 device.handleMeshPacket({id:99,from:destination,to:origin,channel:0,rxTime:Math.floor(Date.now()/1000),payloadVariant:{case:'decoded',value:{portnum:70,payload,requestId:queuedId}}});
 assert.equal(rawRequest,queuedId);assert.equal(received.from,destination);assert.deepEqual(received.data.route,[relay]);assert.deepEqual(received.data.routeBack,[]);
 await device.disconnect();
});
